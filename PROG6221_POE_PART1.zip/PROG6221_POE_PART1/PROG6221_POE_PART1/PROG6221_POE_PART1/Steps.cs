﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROG6221_POE_PART1
{
    internal class Steps
    {
        int stepNumber;
        string stepDescription;

        public Steps(int stepNumber, string stepDescription)
        {
            this.stepNumber = stepNumber;
            this.stepDescription = stepDescription;
        }
        public int StepNumber { get {  return stepNumber; } }
        public string StepDescription() { 
            return stepDescription; 
        }


    }
}
